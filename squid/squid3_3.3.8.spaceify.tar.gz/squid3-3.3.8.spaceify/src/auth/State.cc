#include "squid.h"

#if USE_AUTH
#include "auth/State.h"

CBDATA_NAMESPACED_CLASS_INIT(Auth, StateData);
#endif /* USE_AUTH */
